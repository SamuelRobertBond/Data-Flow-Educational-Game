var canvas = document.getElementById("canvas");
var bRect = canvas.getBoundingClientRect();
var ctx = canvas.getContext("2d");
var out = null;
var index = 0;


canvas.width = bRect.right - bRect.left;
canvas.height = bRect.bottom - bRect.top;

var puzzles = null;

var puzzleIndex = 0;

if(puzzleIndex == 0){
	puzzles = [0, 1];
}else if(puzzleIndex == 1){
	puzzles = [2]
}else if(puzzleIndex == 2){
	puzzles = [3, 4]
}else{
	puzzles = [5];
}

var enableGrid = false;
var enablePuzzleIntro = true;
var enablePuzzleGlossary = false;

var grid = null;

//Draws the grid
function render(){
	if(grid != null){
		grid.draw();
	}
}
setInterval(render, 250);

function changePuzzle(){
	if(grid != null){
		if(grid.isComplete()){
			++index;
			if(index == puzzles.length){
				out.value = "> Set of puzzles is complete!\n\nPlease Hit Home Button!"
			}else{
			grid = new GridController(0, 0, canvas.width, canvas.height, 6, puzzles[index]);
			}
		}
	}
}
setInterval(changePuzzle, 250);

document.addEventListener("DOMContentLoaded", function(e){
	grid = new GridController(0, 0, canvas.width, canvas.height, 6, puzzles[index]);
});