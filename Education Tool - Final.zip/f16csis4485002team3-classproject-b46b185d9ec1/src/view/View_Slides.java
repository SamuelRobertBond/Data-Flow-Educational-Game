package view;

import java.io.File;
import java.net.MalformedURLException;
import java.util.ArrayList;

import controller.Controller_JS;
import controller.Controller_Main;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker.State;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import model.Model_Main;
import model.Section;
import model.Slide;
import netscape.javascript.JSObject;

/**
 * View_Slides
 * 
 * The Slides view loads and formats the individual slides, presenting
 * them to the user for learning.
 * Recall that each slide must belong to a section.
 * The slides are loaded from the application database via Model_Main.
 * A slide may contain static content or an interactive quiz.
 *
 */

public class View_Slides extends View_Main {

	private ArrayList<Slide> slides;
	private int section_id;
	private Section section;
	private int currentSlide;
	static WebView browser = new WebView();
	static WebEngine webEngine = browser.getEngine();
	static ChangeListener<State> listener = new ChangeListener<State>() {
	      @Override 
	      public void changed(ObservableValue ov, State oldState, State newState) {
	        try {
	    	  if (newState == State.SUCCEEDED && webEngine != null) {
	          JSObject jsobj = (JSObject) webEngine.executeScript("window");
	          jsobj.setMember("app", new Controller_JS());
	        }
	        } catch(Exception e) {
	        	System.out.println("yo whats UP!");
	        }
	      }
	    };
	
	public View_Slides(Controller_Main c, int section_id) {
		super(c);
		Model_Main.currentSectionID = section_id;
		this.section_id = section_id;
		section = Model_Main.getSection(this.section_id);
		slides = Model_Main.getSlides(this.section_id);
		currentSlide = 0;
		if (slides.size() < 1) {
			slides.add(new Slide(0, "No slides to display for this section.", "", 0));
		}
		generateSlideView();
	}
	public void generateSlideView() {
		Slide s = slides.get(currentSlide);
		BorderPane grid = new BorderPane();

		// Slide Title
		Text title = new Text(s.title);
		title.setFill(LIGHT_TEXT);
		grid.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);
		
		// Slide Body
		
		webEngine.setUserStyleSheetLocation("file:./DATA/css/slides.css");
		webEngine.loadContent(s.body);
		webEngine.getLoadWorker().stateProperty().addListener(listener);
		
		
		grid.setCenter(browser);
		
		// Navigation buttons
		Button btnBack = new Button("<");
		grid.setLeft(btnBack);
		btnBack.setOnAction(new EventHandler<ActionEvent>() {
		    @Override 
		    public void handle(ActionEvent e) {
		    	if (currentSlide > 0) {
			    	currentSlide--;
			    	generateSlideView();
		    	}
		    }
		});
		Button btnForward = new Button(">");
		grid.setRight(btnForward);
		btnForward.setOnAction(new EventHandler<ActionEvent>() {
		    @Override 
		    public void handle(ActionEvent e) {
		    	if (currentSlide < slides.size() - 1) {
			    	currentSlide++;
			    	generateSlideView();
		    	}
		    }
		});
		
		// Return to Section button on bottom
		Button btnModule = new Button("Return to Module");
		grid.setBottom(btnModule);
		BorderPane.setAlignment(btnModule, Pos.CENTER);
		btnModule.setOnAction(new EventHandler<ActionEvent>() {
		    @Override 
		    public void handle(ActionEvent e) {
		    	controller.showSections(section.module_id);
		    }
		});

		this.setCenter(grid);
	}
	
	public static void closeWebEngine() {
		webEngine.getLoadWorker().stateProperty().removeListener(listener);
	}
	
	public void showPuzzle() {
		File f = new File(System.getProperty("user.dir")+"\\DATA\\Puzzle Base\\CSIS Game\\index.html");
		try {
			webEngine.load(f.toURI().toURL().toString());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
}