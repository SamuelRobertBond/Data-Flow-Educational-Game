package view;

import java.util.ArrayList;

import controller.Controller_Main;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import model.Model_Main;
import model.Module;

/**
 * View_Modules
 * 
 * The Modules view displays a list of modules available to the user.
 * The modules are loaded from the application database via Model_Main
 *
 */

public class View_Modules extends View_Main {
	
	
	public View_Modules(Controller_Main c) {
		super(c);
		generateModuleMenu();
	}
	
	public void generateModuleMenu(){
		ArrayList<Module> modules = Model_Main.getModules();
		
		VBox content = new VBox(SPACING);
		content.setPadding(new Insets(20, 10, 10, 10));
		content.setAlignment(Pos.TOP_CENTER);
		
		Text title = new Text("Select a module");
		title.setFill(LIGHT_TEXT);
		title.getStyleClass().add("home-title");
		content.getChildren().add(title);
		
		HBox buttons = new HBox(SPACING);
		buttons.setAlignment(Pos.CENTER);
		for (int i = 0; i < modules.size(); i++) {
			final Module m = modules.get(i);
			Button btnModule = new Button(m.name);
			btnModule.setPadding(new Insets(20));
			btnModule.setOnAction(new EventHandler<ActionEvent>() {
			    @Override
			    public void handle(ActionEvent e) {
			    	controller.showSections(m.module_id);				       
			    }
			});
			buttons.getChildren().add(btnModule);
		}
		content.getChildren().add(buttons);
		
		// Back button below
		Button btnBack = new Button("Back");
		btnBack.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent e) {
		    	controller.showHome();
			}
		});
		content.getChildren().add(btnBack);
		
		this.setCenter(content);
	}
}
