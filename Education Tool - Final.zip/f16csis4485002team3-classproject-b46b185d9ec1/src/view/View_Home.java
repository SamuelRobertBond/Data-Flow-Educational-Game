package view;

import controller.Controller_Main;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

/**
 * 
 * View_Home
 * 
 * The Home view is displayed when the application is started.
 * It allows the user to login or register. When the user has logged in,
 * they may then view the available modules.
 *
 */

public class View_Home extends View_Main {
	
	public View_Home(Controller_Main c) {
		super(c);
		generateHomeContent();
	}
	
	public void generateHomeContent() {
		VBox content = new VBox(SPACING);
		content.setAlignment(Pos.TOP_CENTER);
		content.setPadding(new Insets(20, 10, 10, 10));
		
		Text app_title = new Text("Welcome to the SHFTET!");
		app_title.setFill(LIGHT_TEXT);
		app_title.getStyleClass().add("home-title");
		content.getChildren().add(app_title);
	
		Text app_subtitle = new Text("Get smart, have fun!");
		app_subtitle.setFill(LIGHT_TEXT);
		content.getChildren().add(app_subtitle);
		
		if (Controller_Main.loggedIn()) {
			Text user_prompt = new Text("What would you like to do, " + Controller_Main.currentUser.name + "?");
			user_prompt.setFill(LIGHT_TEXT);
			content.getChildren().add(user_prompt);
			
			HBox buttons = new HBox(SPACING);
			buttons.setAlignment(Pos.CENTER);
			
			Button btnModules = new Button("View Modules");
			btnModules.setOnAction(new EventHandler<ActionEvent>() {
			    @Override
			    public void handle(ActionEvent e) {
			    	controller.showModules();
			    }
			});
			buttons.getChildren().add(btnModules);
			
			Button btnLogout = new Button("Logout");
			btnLogout.setOnAction(new EventHandler<ActionEvent>() {
			    @Override
			    public void handle(ActionEvent e) {
			    	controller.logout();
			    }
			});
			buttons.getChildren().add(btnLogout);
			
			content.getChildren().add(buttons);
		} else {
			HBox buttons = new HBox(SPACING);
			buttons.setAlignment(Pos.CENTER);
			
			Button btnLogin = new Button("Login");
			btnLogin.setOnAction(new EventHandler<ActionEvent>() {
			    @Override
			    public void handle(ActionEvent e) {
			    	controller.showLogin();
			    }
			});
			buttons.getChildren().add(btnLogin);
			
			Button btnRegister = new Button("Register");
			btnRegister.setOnAction(new EventHandler<ActionEvent>() {
			    @Override
			    public void handle(ActionEvent e) {
			    	controller.showRegister();
			    }
			});
			buttons.getChildren().add(btnRegister);
			
			content.getChildren().add(buttons);
		}
		
		this.setCenter(content);
	}
	
}
