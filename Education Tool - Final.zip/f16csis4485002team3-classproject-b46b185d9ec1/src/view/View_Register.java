package view;

import controller.Controller_Main;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class View_Register extends View_Main {

	public View_Register(Controller_Main c) {
		super(c);
		
		generateView();
	}
	
	private void generateView() {
		VBox content = new VBox(SPACING);
		content.setPadding(new Insets(40,40,40,40));
		
		Text title = new Text("Register");
		title.getStyleClass().add("home-title");
		title.setFill(LIGHT_TEXT);
		content.getChildren().add(title);
		
		Label lblEmail = new Label("Email");
		content.getChildren().add(lblEmail);
		final TextField txtEmail = new TextField();
		content.getChildren().add(txtEmail);
		
		Label lblName = new Label("Full Name");
		content.getChildren().add(lblName);
		final TextField txtName = new TextField();
		content.getChildren().add(txtName);

		Label lblPassword = new Label("Password");
		content.getChildren().add(lblPassword);
		final PasswordField txtPassword = new PasswordField();
		content.getChildren().add(txtPassword);
		
		HBox buttons = new HBox(SPACING);
		
		Button btnSubmit = new Button("Submit");
		btnSubmit.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent e) {
		    	controller.register(txtEmail.getText(), txtName.getText(), txtPassword.getText());
			}
		});
		buttons.getChildren().add(btnSubmit);
		
		Button btnBack = new Button("Back");
		btnBack.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent e) {
		    	controller.showHome();
			}
		});
		buttons.getChildren().add(btnBack);
		
		content.getChildren().add(buttons);
		
		this.setCenter(content);
	}

}
