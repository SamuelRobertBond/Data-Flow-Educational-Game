package view;

import java.io.File;
import java.net.MalformedURLException;

import controller.Controller_JS;
import controller.Controller_Main;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker.State;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import model.Model_Main;
import netscape.javascript.JSObject;

/**
 * View_Main
 * 
 * This abstract class lays the foundation for all of the other views.
 * It generates the basic layout that gives the application a consistent
 * look and feel. Also, it implements any functionality or variables
 * shared by all views.
 *
 */

public abstract class View_Main extends BorderPane {
	
	protected static final int SPACING = 15;
	
	protected Controller_Main controller;
	private GridPane body;

	// Design Properties
	public static final Color LIGHT_TEXT = Color.web("#ebebeb");

	public View_Main(Controller_Main c) {
		controller = c;
		body = new GridPane();
		this.setCenter(body);
		generateHeader();
	}
	
	public void generateHeader() {
		BorderPane header = new BorderPane();
		header.getStyleClass().add("header");
		Text title = new Text("Super Happy Fun Time Education Tool");
		title.getStyleClass().add("header");
		title.setFill(LIGHT_TEXT);
		header.setCenter(title);
		
		Button btnHome = new Button("Home");
		btnHome.getStyleClass().add("header-btn");
		btnHome.setTextFill(LIGHT_TEXT);
		btnHome.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent e) {
		    	controller.showHome();
		    }
		});

		header.setLeft(btnHome);
		BorderPane.setAlignment(btnHome, Pos.CENTER);
		
		Button btnExit = new Button("Exit");
		btnExit.setTextFill(LIGHT_TEXT);
		btnExit.getStyleClass().add("header-btn");
		btnExit.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent e) {
		    	Platform.exit();
			}
		});
		header.setRight(btnExit);
		BorderPane.setAlignment(btnExit, Pos.CENTER);
		
		this.setTop(header);
	}
	
	public void GenerateBottomNav(){
		GridPane bgrid = new GridPane();
	    bgrid.setHgap(10);
	    bgrid.setVgap(12);
		HBox bottom = new HBox();
		bottom.setSpacing(10.0);
		Button exitbtn = new Button("Exit");
		exitbtn.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent e) {
			       Platform.exit();
			    }
			});
		Button homebtn = new Button("Home");
		homebtn.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent e) {
		    	controller.showHome();
		    }
			});
		bottom.getChildren().addAll(homebtn, exitbtn);
		bgrid.add(bottom, 0, 2, 2, 1);
		bgrid.setAlignment(Pos.CENTER);
		this.setBottom(bgrid);
	}
	
	public void loadGame() {
		try {
			WebView browser = new WebView();
			final WebEngine webEngine = browser.getEngine();
			File f = new File(System.getProperty("user.dir")+"\\DATA\\Puzzle Base\\CSIS Game\\index.html");
			webEngine.load(f.toURI().toURL().toString());
			webEngine.getLoadWorker().stateProperty().addListener(new ChangeListener<State>() {
			      @Override 
			      public void changed(ObservableValue ov, State oldState, State newState) {
			    	  if (newState == State.SUCCEEDED && webEngine != null) {
			          JSObject jsobj = (JSObject) webEngine.executeScript("window");
			          jsobj.setMember("app", new Controller_JS());
			          
			        }
			       
			      }
			    });
			this.setCenter(browser);
		} catch(MalformedURLException e) {
			e.printStackTrace();
		}
	}

}
