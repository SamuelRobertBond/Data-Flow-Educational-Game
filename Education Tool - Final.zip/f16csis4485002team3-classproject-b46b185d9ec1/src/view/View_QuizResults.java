package view;

import controller.Controller_Main;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.Model_Main;

public class View_QuizResults extends View_Main {
	
	/**
	 * Quiz Results page
	 * The user is directed here when their quiz grade was not high
	 * enough to continue to the puzzle game.
	 */
	
	private int grade;
	public VBox returnval;
	
	public View_QuizResults(Controller_Main c, int grade) {
		super(c);
		this.grade = grade;
		generateView();
	}
	public VBox returnContent(){
		return returnval;
	}
	public void generateView() {
		VBox content = new VBox(SPACING);
		content.setPadding(new Insets(40));
		
		Text titleText = new Text("Quiz Results");
		titleText.setFill(LIGHT_TEXT);
		titleText.getStyleClass().add("home-title");
		content.getChildren().add(titleText);
		
		Text gradeText = new Text("Your grade: " + grade + "%");
		gradeText.setFill(LIGHT_TEXT);
		content.getChildren().add(gradeText);

		Text resultText = new Text("Sorry, you did not pass the quiz.");
		resultText.setFill(Color.RED);
		content.getChildren().add(resultText);
		
		HBox buttons = new HBox(SPACING);
		buttons.setAlignment(Pos.CENTER);
		
		Button btnAgain = new Button("Try Again");
		btnAgain.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent e) {
		    	controller.showSlides(Model_Main.currentSectionID);
		    }
		});
		buttons.getChildren().add(btnAgain);
		
		Button btnBack = new Button("Return Home");
		btnBack.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent e) {
		    	controller.showHome();
			}
		});
		buttons.getChildren().add(btnBack);
		
		content.getChildren().add(buttons);
		
		this.setCenter(content);
	}
}
