package view;

import java.util.ArrayList;

import controller.Controller_Main;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import model.Model_Main;
import model.Section;

/**
 * View_Sections
 * 
 * The Sections view displays a list of modules available to the user
 * based on a given moduleID.
 * Recall that each section must belong to a module.
 * The sections are loaded from the application database via Model_Main.
 *
 */

public class View_Sections extends View_Main {
	
	private int moduleID;
	
	public View_Sections(Controller_Main c, int moduleID) {
		super(c);
		this.moduleID = moduleID;
		generateSectionMenu();
	}
	
	public void generateSectionMenu() {
		ArrayList<Section> sections = Model_Main.getSections(moduleID);

		VBox content = new VBox(SPACING);
		content.setPadding(new Insets(20, 10, 10, 10));
		content.setAlignment(Pos.TOP_CENTER);

		Text title = new Text("Select a section");
		title.getStyleClass().add("home-title");
		title.setFill(LIGHT_TEXT);
		content.getChildren().add(title);
		
		HBox buttons = new HBox(SPACING);
		buttons.setAlignment(Pos.CENTER);
		
		for (int i = 0;i < sections.size(); i++){
			final Section s = sections.get(i);
			String sectionName = sections.get(i).name;
			Button mod1 = new Button(sectionName);
			mod1.setPadding(new Insets(20));
			mod1.setOnAction(new EventHandler<ActionEvent>() {
			    @Override 
			    public void handle(ActionEvent e) {
			    	controller.showSlides(s.section_id);
			    }
			});
			buttons.getChildren().add(mod1);
		}
		
		content.getChildren().add(buttons);
		
		// Back button below
		Button btnBack = new Button("Back");
		btnBack.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent e) {
		    	controller.showModules();
			}
		});
		content.getChildren().add(btnBack);
		
		this.setCenter(content);
	}
}
