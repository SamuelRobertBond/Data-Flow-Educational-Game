package controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.security.MessageDigest;

import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.Model_Main;
import model.User;
import view.View_Home;
import view.View_Login;
import view.View_Main;
import view.View_Modules;
import view.View_QuizResults;
import view.View_Register;
import view.View_Sections;
import view.View_Slides;

/**
 * Controller_Main
 * 
 * This primary controller class is the entry point for the application.
 * This controller pulls data from the models (via Model_Main) and creates
 * the views to be rendered to the user.
 *
 */

public class Controller_Main  extends Application {
	
	// Singleton for access from Controller_JS
	private static Controller_Main instance;
	
	// Static user reference for access to logged in user data
	public static User currentUser = null;
	
	// Grade required to pass a quiz
	public static final int PASSING_GRADE = 75;
	
	private Scene scene;
	private Stage mainStage;
	private View_Main mainPane;
	public View_Slides slideView;
	
	/**
	 * Application entry point
	 * @param args Command line arguments
	 */
	public static void main(String[] args){
		launch(args);
	}
	
	/**
	 * Retrieve the current running instance of the main controller, which is also the current JavaFX Application
	 * @return Controller_Main singleton object currently being using in the application
	 */
	public static Controller_Main getInstance() {
		return instance;
	}
	
	/**
	 * Test whether there is a logged in user or not
	 * @return true if a user is currently logged in, false otherwise
	 */
	public static boolean loggedIn() {
		return currentUser != null;
	}
	
	/**
	 * Setup for application
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		// Add singleton instance
		instance = this;
		
		mainStage = new Stage();
		mainPane = new View_Home(this);
		primaryStage = mainStage;
		scene = new Scene(mainPane);
		
		// Load external CSS sheet as JavaFX Skin
		File file = new File("DATA/css/main.css");
		URL url = file.toURI().toURL();
		scene.getStylesheets().add(url.toExternalForm());

		mainStage.setScene(scene);
		mainStage.setFullScreen(true);
		primaryStage.setMaximized(true);
		primaryStage.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);
        primaryStage.show();
	}
	
	/**
	 * Note: Each of the following methods prefixed with "show"
	 * perform the necessary operations required to show a specific view.
	 * For most, this involves setting the root of the JavaFX application's
	 * scene and passing an instance of the running controller.
	 */
	
	public void showHome() {
		scene.setRoot(new View_Home(this));
	}
	
	public void showModules() {
		scene.setRoot(new View_Modules(this));
	}
	
	public void showSections(int module_id) {
		scene.setRoot(new View_Sections(this, module_id));
	}
	
	public void showSlides(int section_id) {
		slideView = new View_Slides(this, section_id);
		scene.setRoot(slideView);
	}
	
	public void showLogin() {
		scene.setRoot(new View_Login(this));
	}
	
	public void showRegister() {
		scene.setRoot(new View_Register(this));
	}
	
	public void showQuizResults(int grade) {
		if (grade < PASSING_GRADE){
			scene.setRoot(new View_QuizResults(this, grade));
		}else{
			try{
				String line, fileText=""; 
				File file = new File(System.getProperty("user.dir")+"\\DATA\\Puzzle Base\\CSIS Game\\scripts\\Grid\\main.js");
				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr);
				while((line = br.readLine()) !=null){
					if (line.contains("var puzzleIndex =")){
						line = "var puzzleIndex ="+ (Model_Main.currentSectionID) +";";
					}
					fileText+=line+"\n";
				}
				br.close();
				fr.close();
				FileWriter fw = new FileWriter(file);
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(fileText);
				bw.close();
				fw.close();
			} catch(IOException e) {
		        e.printStackTrace();
	        }
			
			slideView.showPuzzle();
		}
	}
	
	/**
	 * Attempt to register a user, and display an appropriate view based on the result
	 * If the user is successfully created, View_Home will be displayed.
	 * If there are registration errors, View_Register will be displayed.
	 * @param email Email of the user to create
	 * @param name Name of the user to create
	 * @param password Plaintext password of the user to create
	 */
	public void register(String email, String name, String password) {
		try {
			String passwordDigest = getPasswordDigest(password);

			// Attempt to create user with given information
			if (Model_Main.createUser(email, name, passwordDigest)) {
				showHome();
			} else {
				// An error occurred: show the form again
				showRegister();
			}
		} catch (Exception e) {
			e.printStackTrace();
			showRegister();
		}
	}
	
	/**
	 * Attempt to login a user account
	 * @param email Email entered by user
	 * @param password Plaintext password entered by user
	 */
	public void login(String email, String password) {
		String passwordDigest = getPasswordDigest(password);
		
		if (Model_Main.loginUser(email, passwordDigest)) {
			showHome();
		} else {
			showLogin();
		}
	}
	
	/**
	 * Delete currentUser, logging the current user out (loggedIn() will return false)
	 */
	public void logout() {
		currentUser = null;
		showHome();
	}
	
	/**
	 * Get the password digest for a given plaintext password
	 * @param password The plaintext password
	 * @return SHA-256 hash of the password input for comparison with database
	 */
	private String getPasswordDigest(String password) {
		// Generate password digest using SHA-256
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(password.getBytes("UTF-8"));
			// Create string from hash byte array
			String passwordDigest = new String(hash);
			return passwordDigest;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
