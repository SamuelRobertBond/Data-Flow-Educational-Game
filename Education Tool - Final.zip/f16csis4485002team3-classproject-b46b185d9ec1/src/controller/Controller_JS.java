package controller;

import model.Model_Main;

/**
 * Controller_JS
 * 
 * This class serves as a bridge between JavaScript code executing 
 * in a WebView and Java code in the main application.
 * All upcalls from JavaScript involve this class.
 *
 */

public class Controller_JS {

	/**
	 * Upcall method used to get quiz grade from WebView
	 * used for user tracking
	 * @param grade A grade from 0 to 100 representing the user's quiz result
	 * @throws IllegalArgumentException if the grade is not within the range [0, 100]
	 */
	public void updateGrade(int grade){
		if (grade > 100 || grade < 0) {
			throw new IllegalArgumentException();
		}
		Model_Main.updateGrade(Controller_Main.currentUser.user_id, Model_Main.currentSectionID, grade);
		Controller_Main.getInstance().showQuizResults(grade);
	}
	
	/**
	 * Update that puzzle was completed
	 * used for user tracking
	 */
	public void completePuzzle(){
		Model_Main.completePuzzle();
	}
	/**
	 * Used by puzzle game to get current section that was completed.
	 * @return section id of the last created section
	 */
	public double getSectionID(){
		System.out.println("celebrate");
		return 1;// Model_Main.currentSectionID;
	}
}
