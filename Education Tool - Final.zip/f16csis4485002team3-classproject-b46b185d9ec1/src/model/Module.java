package model;

/**
 * Module
 * 
 * Represents a row from the 'modules' table in the database
 *
 */

public class Module {
	
	public int module_id;
	public String name;
	
	public Module(int module_id, String name) {
		this.module_id = module_id;
		this.name = name;
	}
}
