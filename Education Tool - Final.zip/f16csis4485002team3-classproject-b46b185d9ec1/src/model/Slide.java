package model;

/**
 * Slide
 * 
 * Represents a row from the 'slides' table in the database
 *
 */

public class Slide {
	public int slide_id;
	public String title;
	public String body;
	public int section_id;
	
	public Slide(int slide_id, String title, String body, int section_id) {
		this.slide_id = slide_id;
		this.title = title;
		this.body = body;
		this.section_id = section_id;
	}
}
