package model;

public class User {
	
	public int user_id;
	public String email;
	public String name;
	public String password_digest;
	
	public User(int user_id, String email, String name, String password_digest) {
		this.user_id = user_id;
		this.email = email;
		this.name = name;
		this.password_digest = password_digest;
	}
}
