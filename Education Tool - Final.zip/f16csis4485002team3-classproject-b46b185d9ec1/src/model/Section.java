package model;

/**
 * Section
 * 
 * Represents a row from the 'sections' table in the database
 *
 */

public class Section {
	
	public int section_id;
	public String name;
	public int module_id;
	
	public Section(int section_id, String name, int module_id) {
		this.section_id = section_id;
		this.name = name;
		this.module_id = module_id;
	}
}
