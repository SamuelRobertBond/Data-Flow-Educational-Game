package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import controller.Controller_Main;

/**
 * Model_Main
 * 
 * This class handles all interactions that occurs with the local SQLite database.
 * The schema is contained in the methods within this class, meaning that if
 * the database does not yet exist, it will be created automatically.
 *
 */

public class Model_Main {

	private static final String SCHEMA_MODULES = "CREATE TABLE IF NOT EXISTS \"modules\" ( `module_id` INT NOT NULL UNIQUE, `name` VARCHAR, PRIMARY KEY(`module_id`) )";
	private static final String SCHEMA_SECTIONS = "CREATE TABLE IF NOT EXISTS \"sections\" ( `section_id` INT NOT NULL UNIQUE, `name` VARCHAR, `module_id` INT NOT NULL, PRIMARY KEY(`section_id`) )";
	private static final String SCHEMA_SLIDES = "CREATE TABLE IF NOT EXISTS \"slides\" ( `slide_id` INT NOT NULL UNIQUE, `title` VARCHAR, `body` TEXT, `section_id` INT NOT NULL, PRIMARY KEY(`slide_id`) )";
	private static final String SCHEMA_USERS = "CREATE TABLE IF NOT EXISTS `users` ( `user_id` INTEGER PRIMARY KEY AUTOINCREMENT, `email` TEXT NOT NULL, `name` TEXT, `password_digest` TEXT NOT NULL )";
	private static final String SCHEMA_PUZZLES = "CREATE TABLE IF NOT EXISTS `puzzles` ( `user_id` INTEGER, `section_id` INTEGER, `completed` INTEGER, PRIMARY KEY(`user_id`,`section_id`) )";
	private static final String SCHEMA_GRADES = "CREATE TABLE IF NOT EXISTS `grades` ( `grade` INTEGER, `user_id` INTEGER, `section_id` INTEGER, PRIMARY KEY(`user_id`,`section_id`) )";
	
	private static final String DB_PATH = "DATA/shftet.db";
	private static Connection connection = null;
	public static int currentSectionID;
	
	/**
	 * Get a connection to the local database
	 * This method assures that multiple connections are not opened
	 * @return Connection object for the local database
	 */
	public static Connection getConnection() {
	    // If not already connected, connect to local DB
		if (connection == null) {
		    try {
		    	Class.forName("org.sqlite.JDBC");
		    	connection = DriverManager.getConnection("jdbc:sqlite:" + DB_PATH);
		    } catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			System.out.println("Opened database successfully");
	    } 
		
		// Return database connection		
	    return connection;
	}
	
	/**
	 * Bind Modules in the local database to Module objects and return as an ArrayList
	 * @return ArrayList of Module objects from database
	 */
	public static ArrayList<Module> getModules() {
		Connection c = getConnection();
		try {
			Statement stmt = c.createStatement();
			stmt.execute(SCHEMA_MODULES);
			ResultSet resultSet = stmt.executeQuery("SELECT * FROM modules");
			ArrayList<Module> modules = new ArrayList<Module>();
			
			while (resultSet.next()) {
				Module m = new Module(resultSet.getInt("module_id"), resultSet.getString("name"));
				modules.add(m);
			}
			
			return modules;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Bind Sections in the local database to Section objects and return as an ArrayList
	 * @param module_id id of Module corresponding to Sections
	 * @return ArrayList of Section objects from database
	 */
	public static ArrayList<Section> getSections(int module_id) {
		Connection c = getConnection();
		try {
			Statement stmt = c.createStatement();
			stmt.execute(SCHEMA_SECTIONS);
			ResultSet resultSet = stmt.executeQuery("SELECT * FROM sections WHERE `module_id` = " + module_id);
			ArrayList<Section> sections = new ArrayList<Section>();
			
			while (resultSet.next()) {
				Section s = new Section(resultSet.getInt("section_id"), resultSet.getString("name"), module_id);
				sections.add(s);
			}
			
			return sections;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Bind Slides in the local database to Slide objects and return as an ArrayList
	 * @param section_id id of Section corresponding to slides
	 * @return ArrayList of Slide objects from database
	 */
	public static ArrayList<Slide> getSlides(int section_id) {
		Connection c = getConnection();
		try {
			Statement stmt = c.createStatement();
			stmt.execute(SCHEMA_SLIDES);
			ResultSet resultSet = stmt.executeQuery("SELECT * FROM slides WHERE `section_id` = " + section_id);
			ArrayList<Slide> slides = new ArrayList<Slide>();
			
			while (resultSet.next()) {
				Slide s = new Slide(resultSet.getInt("slide_id"), resultSet.getString("title"), resultSet.getString("body"), section_id);
				slides.add(s);
			}
			
			return slides;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Query single Section object from database and bind to Section object
	 * @param section_id id of Section to retrieve from DB
	 * @return Section object corresponding to section_id
	 */
	public static Section getSection(int section_id) {
		Connection c = getConnection();
		try {
			Statement stmt = c.createStatement();
			ResultSet resultSet = stmt.executeQuery("SELECT * FROM sections WHERE `section_id` = " + section_id);
			
			Section section = null;
			
			if (resultSet.next()) {
				section = new Section(resultSet.getInt("section_id"), resultSet.getString("name"), resultSet.getInt("module_id"));
			}
			
			return section;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Create and log in a new user if the user's email does not already exist
	 * Post condition: Controller_Main.currentUser is set to the now logged in user if successful
	 * @param email Email of new user
	 * @param name Name of new user
	 * @param passwordDigest Computed password digest of new user (NOT plaintext password)
	 * @return true if created and logged in user successfully, false otherwise
	 */
	public static boolean createUser(String email, String name, String passwordDigest) {
		if (email == null || name == null || passwordDigest == null) {
			return false;
		}
		
		Connection c = getConnection();
		try {
			Statement stmt = c.createStatement();
			stmt.execute(SCHEMA_USERS);
			
			// Check if user exists
			ResultSet resultSet = stmt.executeQuery("SELECT * FROM users WHERE `email`='" + email+"'");
			
			if (!resultSet.next()) {
				// Insert user
				stmt.execute("INSERT INTO users (email, name, password_digest) VALUES ('"+ email +"','"+ name +"','"+ passwordDigest +"')");
				int new_user_id = stmt.getGeneratedKeys().getInt(1);
				// Set current user
				Controller_Main.currentUser = new User(new_user_id, email, name, passwordDigest);
				System.out.println("User created");
				return true;
			} else {
				System.out.println("User with that email already exists");
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * Login a user, setting Controller_Main.currentUser for access from other parts of the application
	 * @param email The user account's email
	 * @param passwordDigest The password digest of the user password
	 * @return true if the login was successful, false otherwise
	 */
	public static boolean loginUser(String email, String passwordDigest) {
		if (email == null || passwordDigest == null) {
			return false;
		}
		
		Connection c = getConnection();
		try {
			Statement stmt = c.createStatement();
			stmt.execute(SCHEMA_USERS);
			ResultSet resultSet = stmt.executeQuery("SELECT * FROM users WHERE `email` = '" + email + "'");
			
			// If user was found
			if (resultSet.next()) {
				// Check password digest
				if (resultSet.getString("password_digest").equals(passwordDigest)) {
					Controller_Main.currentUser = new User(resultSet.getInt("user_id"), resultSet.getString("email"), resultSet.getString("name"), resultSet.getString("password_digest"));
					return true;
				} else {
					// Incorrect PW
					return false;
				}
			} else {
				// User not found
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * Update (or create if nonexistant) a grade for a given user.
	 * The user_id and section_id form a composite primary key, so there is exactly one grade for each (user, section) pairing
	 * @param user_id The user whose grade will be updated
	 * @param section_id The section ID the user received the grade for
	 * @param grade The grade, between 0 and 100, to store in the database
	 * @throws IllegalArgumentException if the grade is not within the range [0, 100]
	 */
	public static void updateGrade(int user_id, int section_id, int grade) {
		if (grade > 100 || grade < 0) {
			throw new IllegalArgumentException();
		}
		Connection c = getConnection();
		try {
			Statement stmt = c.createStatement();
			stmt.execute(SCHEMA_GRADES);
			stmt.execute("INSERT OR REPLACE INTO grades (user_id, section_id, grade) VALUES ('"+user_id+"','"+section_id+"','"+grade+"')");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void completePuzzle() {
		
	}
	
	/**
	 * Get highest grade for logged in user, given a section
	 * To be used for user profile, showing completed quizzes and puzzles
	 * @param section_id The section for which the grade is to be retrieved
	 * @return The grade, between 0 and 100, that the user received for the section, or -1 if no grade was present
	 */
	public static int getGrade(int section_id) {
		Connection c = getConnection();
		try {
			Statement stmt = c.createStatement();
			stmt.execute(SCHEMA_GRADES);
			ResultSet resultSet = stmt.executeQuery("SELECT * FROM grades WHERE `section_id`="+section_id+" ORDER_BY grade LIMIT 1");
			if (resultSet.next()) {
				return resultSet.getInt("grade");
			} else {
				return -1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return -1;
		}
	}
	
	/**
	 * Delete a user
	 * @param email The email used to identify the user to be deleted
	 * @return true if the operation completed successfully, false if an error occurred
	 */
	public static boolean deleteUser(String email) {
		Connection c = getConnection();
		try {
			Statement stmt = c.createStatement();
			stmt.execute(SCHEMA_GRADES);
			stmt.execute("DELETE FROM `users` WHERE `email`='" + email+"'");
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
