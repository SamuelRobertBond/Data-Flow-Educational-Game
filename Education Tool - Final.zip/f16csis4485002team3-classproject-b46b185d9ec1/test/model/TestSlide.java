package model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestSlide {

	@Test
	public void testConstructor() {
		Slide testSlide = new Slide(5, "Test Slide", "Test Body", 6);
		assertNotNull("Slide constructor failed", testSlide);
		assertEquals("Slide constructor did not set slide_id", 5, testSlide.slide_id);
		assertEquals("Slide constructor did not set slide title", "Test Slide", testSlide.title);
		assertEquals("Slide constructor did not set slide body", "Test Body", testSlide.body);
		assertEquals("Slide constructor did not set section_id", 6, testSlide.section_id);
	}

}
