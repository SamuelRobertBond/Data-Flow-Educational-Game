package model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestModule {

	@Test
	public void testConstructor() {
		Module testModule = new Module(1, "Test Module");
		assertNotNull("Module constructor failed", testModule);
		assertEquals("Module constructor did not set module_id", 1, testModule.module_id);
		assertEquals("Module constructor did not set name", "Test Module", testModule.name);
	}

}
