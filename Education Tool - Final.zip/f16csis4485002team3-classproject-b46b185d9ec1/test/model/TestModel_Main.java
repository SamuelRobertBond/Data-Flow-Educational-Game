package model;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import controller.Controller_Main;

public class TestModel_Main {

	private static final String TEST_USER_EMAIL = "testuser1234@example.com";
	
	@Test
	public void testGetConnection() {
		assertNotNull("getConnection failed", Model_Main.getConnection());
	}
	
	@Test
	public void testGetModules() {
		ArrayList<Module> modules = Model_Main.getModules();
		assertNotNull("getModules failed", modules);
		assertEquals("No modules were returned", true, modules.size() > 0);
	}
	
	@Test
	public void testGetSections() {
		ArrayList<Section> sections = Model_Main.getSections(1);
		assertNotNull("getSections failed", sections);
		assertEquals("No sections were returned for module_id=1", true, sections.size() > 0);
		// Test with invalid model ID
		sections = Model_Main.getSections(-1);
		assertEquals("Slides returned for invalid ID", true, sections.size() == 0);
	}

	@Test
	public void testGetSlides() {
		ArrayList<Slide> slides = Model_Main.getSlides(1);
		assertNotNull("getSlides failed", slides);
		assertEquals("No slides were returned for section_id=1", true, slides.size() > 0);
		// Test with invalid section ID
		slides = Model_Main.getSlides(-1);
		assertEquals("Slides returned for invalid ID", true, slides.size() == 0);
	}
	
	@Test
	public void testGetSection() {
		Section section = Model_Main.getSection(1);
		assertNotNull("getSection failed", section);
		assertEquals("Incorrect section retrieved or incorrect binding for getSection()", "Logic Operators", section.name);
		assertEquals("Incorrect module_id for getSection()", 1, section.module_id);
	}
	
	@Test
	public void testCreateUser_InvalidParameters() {
		assertEquals("Invalid parameters accepted", false, Model_Main.createUser(null, null, null));
	}
	
	@Test
	public void testCreateUser_Successful() {
		// Check that the operation completes
		assertEquals("createUser failed", true, Model_Main.createUser(TEST_USER_EMAIL, "Test User", "testdigest"));
		// Check that the user is logged in
		assertNotNull("User was not logged in after createUser", Controller_Main.currentUser);
		// Delete the user
		assertEquals("Test user was not deleted", true, Model_Main.deleteUser(TEST_USER_EMAIL));
	}
	
	@Test
	public void testLoginUser_DoesNotExist() {
		// Delete our test user account just to be sure
		assertEquals("Test user account was not deleted", true, Model_Main.deleteUser(TEST_USER_EMAIL));
		
		assertEquals("Login was successful for nonexistant user", false, Model_Main.loginUser(TEST_USER_EMAIL, "testdigest"));
	}
	
	@Test
	public void testLoginUser_IncorrectPassword() {
		// Add the test user
		assertEquals("Test user could not be added", true, Model_Main.createUser(TEST_USER_EMAIL, "Test User", "testdigest"));
		// Logout (user should be logged in automatically)
		Controller_Main.currentUser = null;
		// Attempt login with incorrect password
		assertEquals("Test user logged in with incorrect password", false, Model_Main.loginUser(TEST_USER_EMAIL, "NOT the testdigest"));
		// Delete the test user
		assertEquals("Test user was not deleted", true, Model_Main.deleteUser(TEST_USER_EMAIL));
	}
	
	@Test
	public void testLoginUser_Successful() {
		// Add the test user
		assertEquals("Test user could not be added", true, Model_Main.createUser(TEST_USER_EMAIL, "Test User", "testdigest"));
		// Attempt successful login
		assertEquals("Test user could not login with correct email/pw", true, Model_Main.loginUser(TEST_USER_EMAIL, "testdigest"));
		// Delete the test user
		assertEquals("Test user was not deleted", true, Model_Main.deleteUser(TEST_USER_EMAIL));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testUpdateGrade_InvalidLowerBound() {
		Model_Main.updateGrade(0, 0, -1);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testUpdateGrade_InvalidLowerMiddle() {
		Model_Main.updateGrade(0, 0, -10);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testUpdateGrade_InvalidUpperBound() {
		Model_Main.updateGrade(0, 0, 101);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testUpdateGrade_InvalidUpperMiddle() {
		Model_Main.updateGrade(0, 0, 200);
	}
	
	@Test
	public void testGetGrade_NonexistantSection() {
		assertEquals("Grade returned for nonexistant section", -1, Model_Main.getGrade(-1));
	}
	
	@Test
	public void testDeleteUser() {
		// Add the test user
		assertEquals("Test user could not be added", true, Model_Main.createUser(TEST_USER_EMAIL, "Test User", "testdigest"));
		// Delete the test user
		assertEquals("Test user was not deleted", true, Model_Main.deleteUser(TEST_USER_EMAIL));
	}
}
