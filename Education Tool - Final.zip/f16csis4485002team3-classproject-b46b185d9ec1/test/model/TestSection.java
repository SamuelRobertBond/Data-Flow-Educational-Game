package model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestSection {
	
	@Test
	public void testConstructor() {
		Section testSection = new Section(3, "Test Section", 4);
		assertNotNull("Section constructor failed", testSection);
		assertEquals("Section constructor did not set section_id", 3, testSection.section_id);
		assertEquals("Section constructor did not set name", "Test Section", testSection.name);
		assertEquals("Section constructor did not set module_id", 4, testSection.module_id);
	}

}
