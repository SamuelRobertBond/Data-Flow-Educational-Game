package model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestUser {
	
	@Test
	public void testConstructor() {
		User testUser = new User(7, "email@example.com", "Test Name", "Test Digest");
		assertNotNull("User constructor failed", testUser);
		assertEquals("User constructor did not set user_id", 7, testUser.user_id);
		assertEquals("User constructor did not set email", "email@example.com", testUser.email);
		assertEquals("User constructor did not set name", "Test Name", testUser.name);
		assertEquals("User constructor did not set password digest", "Test Digest", testUser.password_digest);
	}

}
