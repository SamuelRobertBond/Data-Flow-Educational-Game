package controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import model.Model_Main;

public class TestController_Js {

	/**
	 * Test methods relating to the Controller_JS, the Javascript bridge class
	 */
	
	/*
	 * updateGrade
	 */
	@Test(expected=IllegalArgumentException.class)
	public void testUpdateGrade_NegativeMiddle() {
		new Controller_JS().updateGrade(-100);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testUpdateGrade_NegativeBoundary() {
		new Controller_JS().updateGrade(-1);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testUpdateGrade_PositiveBoundary() {
		new Controller_JS().updateGrade(101);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testUpdateGrade_PositiveMiddle() {
		new Controller_JS().updateGrade(200);
	}
	
	/** Note: No test is implemented for completePuzzle() because
	 * it is a single-line void method calling a method in Model_Main
	 */
	
	/*
	 * getSectionID
	 */
	@Test
	public void testGetSectionID() {
		Controller_JS test = new Controller_JS();
		Model_Main.currentSectionID = 5;
		assertEquals("The correct Section ID was not retrieved.", 5, test.getSectionID());
	}
}
