import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    controller.TestController_Js.class,
    model.TestModel_Main.class,
    model.TestModule.class,
    model.TestSection.class,
    model.TestSlide.class,
    model.TestUser.class
})
public class RunSuite {
}
