# Super Happy Fun Time Educational Tool

Project for CSIS 4485 Software and Security Engineering

## Team
* Sam Bond
* James Cincotti
* Stephen Grice
* Mike Partlow

## Requirements
This application requires Java 8 and JavaFX to compile